"""Offline billing software for a grocery / provision store.

Runs on the shop computer at http://127.0.0.1:5000 - no internet needed.
Data lives in one SQLite file: data/billing.db
"""
import io
import os
import re
import secrets
import sqlite3
import tempfile
import threading
import webbrowser
from datetime import date, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from functools import wraps
from xml.sax.saxutils import escape

from flask import (Flask, abort, flash, g, jsonify, redirect, render_template,
                   request, send_file, send_from_directory, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("BILLING_DATA_DIR", os.path.join(BASE, "data"))
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "billing.db")

UNITS = ["kg", "g", "piece", "dozen", "litre", "packet"]
MODES = ["Cash", "UPI"]
DEFAULT_SETTINGS = {
    "store_name": "Rajeshwari Stores",
    "store_address": "Enter your store address in Settings",
    "store_mobile": "",
    "gst_number": "",
    "show_gst": "0",
    "bill_footer": "Thank you! Visit again.",
    "backup_folder": os.path.join(DATA_DIR, "backups"),
    "last_bill_no": "0",
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL COLLATE NOCASE,
  pw_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('owner','staff')),
  active INTEGER NOT NULL DEFAULT 1, must_change INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS products(
  id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL COLLATE NOCASE,
  unit TEXT NOT NULL, price INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT);
CREATE TABLE IF NOT EXISTS customers(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, mobile TEXT, address TEXT,
  opening_balance INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS customer_prices(
  customer_id INTEGER NOT NULL, product_id INTEGER NOT NULL, rate INTEGER NOT NULL,
  updated_at TEXT, PRIMARY KEY(customer_id, product_id));
CREATE TABLE IF NOT EXISTS bills(
  id INTEGER PRIMARY KEY, bill_no INTEGER NOT NULL, version INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active', customer_id INTEGER NOT NULL,
  bill_date TEXT NOT NULL, subtotal INTEGER NOT NULL, round_off INTEGER NOT NULL,
  total INTEGER NOT NULL, paid_now INTEGER NOT NULL DEFAULT 0, pay_mode TEXT,
  prev_balance INTEGER NOT NULL, new_balance INTEGER NOT NULL, note TEXT,
  cancel_reason TEXT, created_by TEXT, created_at TEXT,
  show_discount INTEGER NOT NULL DEFAULT 1, UNIQUE(bill_no, version));
CREATE TABLE IF NOT EXISTS bill_items(
  id INTEGER PRIMARY KEY, bill_id INTEGER NOT NULL, product_id INTEGER,
  name TEXT NOT NULL, unit TEXT NOT NULL, qty TEXT NOT NULL, rate INTEGER NOT NULL,
  discount INTEGER NOT NULL DEFAULT 0, amount INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL, pay_date TEXT NOT NULL,
  amount INTEGER NOT NULL, mode TEXT, note TEXT, voided INTEGER NOT NULL DEFAULT 0,
  created_by TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY, ts TEXT, username TEXT, action TEXT, detail TEXT);
CREATE INDEX IF NOT EXISTS ix_bills_cust ON bills(customer_id, status);
CREATE INDEX IF NOT EXISTS ix_bills_date ON bills(bill_date);
CREATE INDEX IF NOT EXISTS ix_items_bill ON bill_items(bill_id);
CREATE INDEX IF NOT EXISTS ix_pay_cust ON payments(customer_id, voided);
"""

BALANCE_SQL = """
SELECT c.*, c.opening_balance
  + COALESCE((SELECT SUM(b.total - b.paid_now) FROM bills b
              WHERE b.customer_id = c.id AND b.status = 'active'), 0)
  - COALESCE((SELECT SUM(p.amount) FROM payments p
              WHERE p.customer_id = c.id AND p.voided = 0), 0) AS balance
FROM customers c
"""

app = Flask(__name__)


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
def connect():
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def db():
    if "db" not in g:
        g.db = connect()
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db():
    conn = connect()
    conn.executescript(SCHEMA)
    # Safe migrations for existing databases
    bill_cols = {r["name"] for r in conn.execute("PRAGMA table_info(bills)")}
    if "show_discount" not in bill_cols:
        conn.execute("ALTER TABLE bills ADD COLUMN show_discount INTEGER NOT NULL DEFAULT 1")
    item_cols = {r["name"] for r in conn.execute("PRAGMA table_info(bill_items)")}
    if "discount" not in item_cols:
        conn.execute("ALTER TABLE bill_items ADD COLUMN discount INTEGER NOT NULL DEFAULT 0")

    for k, v in DEFAULT_SETTINGS.items():
        conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
    if not conn.execute("SELECT 1 FROM users").fetchone():
        conn.execute(
            "INSERT INTO users(username,pw_hash,role,must_change) VALUES(?,?,?,1)",
            ("owner", generate_password_hash("owner123"), "owner"))
    conn.commit()
    conn.close()


def secret_key():
    path = os.path.join(DATA_DIR, "secret.key")
    if not os.path.exists(path):
        with open(path, "w") as fh:
            fh.write(secrets.token_hex(32))
    with open(path) as fh:
        return fh.read().strip()


def get_settings():
    s = dict(DEFAULT_SETTINGS)
    for r in db().execute("SELECT key,value FROM settings"):
        s[r["key"]] = r["value"]
    return s


def now():
    return datetime.now().isoformat(timespec="seconds")


def audit(action, detail="", user=None):
    if user is None:
        user = g.user["username"] if getattr(g, "user", None) else "-"
    db().execute("INSERT INTO audit_log(ts,username,action,detail) VALUES(?,?,?,?)",
                 (now(), user, action, detail))


# --------------------------------------------------------------------------
# Money / quantity helpers (money is stored as integer paise)
# --------------------------------------------------------------------------
def parse_money(s, allow_neg=False):
    try:
        v = Decimal((s or "").strip().replace(",", "") or "0")
    except InvalidOperation:
        raise ValueError("Please enter a valid amount")
    if not v.is_finite():
        raise ValueError("Please enter a valid amount")
    if v.as_tuple().exponent < -2:
        raise ValueError("Amounts can have at most 2 decimal places")
    if v < 0 and not allow_neg:
        raise ValueError("Amount cannot be negative")
    return int((v * 100).to_integral_value(ROUND_HALF_UP))


def parse_qty(s):
    try:
        v = Decimal((s or "").strip())
    except InvalidOperation:
        raise ValueError("Please enter a valid quantity")
    if not v.is_finite() or v <= 0:
        raise ValueError("Quantity must be greater than zero")
    if v.as_tuple().exponent < -3:
        raise ValueError("Quantity can have at most 3 decimal places")
    return v


def line_amount(qty, rate_paise, discount_paise=0):
    gross = int((qty * rate_paise).quantize(Decimal(1), ROUND_HALF_UP))
    return max(0, gross - int(discount_paise or 0))


def qty_str(q):
    return format(Decimal(str(q)).normalize(), "f")


def indian(n):
    s = str(n)
    if len(s) <= 3:
        return s
    last3, rest, groups = s[-3:], s[:-3], []
    while len(rest) > 2:
        groups.insert(0, rest[-2:])
        rest = rest[:-2]
    if rest:
        groups.insert(0, rest)
    return ",".join(groups + [last3])


def money(p):
    p = int(p or 0)
    sign = "-" if p < 0 else ""
    p = abs(p)
    return f"{sign}{indian(p // 100)}.{p % 100:02d}"


def money_plain(p):
    p = int(p or 0)
    return f"{p // 100}.{p % 100:02d}" if p >= 0 else f"-{abs(p) // 100}.{abs(p) % 100:02d}"


def bill_label(b):
    """RSGP + YYYY + MM + 6-digit bill number, e.g. RSGP202611000001 (adds _v1 for edits)."""
    ym = (b["bill_date"] or "")[:7].replace("-", "")
    if len(ym) != 6 or not ym.isdigit():
        ym = datetime.now().strftime("%Y%m")
    base = f"RSGP{ym}{int(b['bill_no']):06d}"
    return base if b["version"] == 0 else f"{base}_v{b['version']}"


def bill_filename(b, customer_name):
    """customername_RS<bill_no>_<DDMMYYYY>_<HHMMSS> e.g. customer1_RS15_24112026_234052."""
    safe = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", customer_name or "").strip()
    safe = re.sub(r"\s+", "_", safe) or "customer"
    created = b["created_at"] or ""
    try:
        dt = datetime.fromisoformat(created)
        stamp = dt.strftime("%d%m%Y_%H%M%S")
    except ValueError:
        stamp = datetime.now().strftime("%d%m%Y_%H%M%S")
    uid = f"RS{b['bill_no']}" if b["version"] == 0 else f"RS{b['bill_no']}_v{b['version']}"
    return f"{safe}_{uid}_{stamp}"


def password_problems(pw):
    missing = []
    if len(pw or "") < 6:
        missing.append("at least 6 characters")
    if not re.search(r"[A-Z]", pw or ""):
        missing.append("a capital letter")
    if not re.search(r"[a-z]", pw or ""):
        missing.append("a small letter")
    if not re.search(r"[0-9]", pw or ""):
        missing.append("a number")
    if not re.search(r"[^A-Za-z0-9]", pw or ""):
        missing.append("a symbol (such as ! @ # $ %)")
    return missing


def password_error(pw):
    miss = password_problems(pw)
    return ("Password must contain " + ", ".join(miss) + ".") if miss else None


def parse_date(s):
    try:
        return datetime.strptime((s or "").strip(), "%Y-%m-%d").date().isoformat()
    except ValueError:
        raise ValueError("Please enter a valid date")


def compute_totals(items):
    subtotal = sum(i["amount"] for i in items)
    total = ((subtotal + 50) // 100) * 100  # round to nearest rupee, half up
    return subtotal, total - subtotal, total


@app.template_filter("money")
def money_filter(p):
    return money(p)


@app.template_filter("qty")
def qty_filter(q):
    return qty_str(q)


@app.template_filter("num")
def num_filter(x):
    return format(Decimal(str(round(float(x or 0), 3))).normalize(), "f")


@app.template_filter("label")
def label_filter(b):
    return bill_label(b)


@app.template_filter("dmy")
def dmy_filter(s):
    try:
        return datetime.strptime(s, "%Y-%m-%d").strftime("%d-%m-%Y")
    except (TypeError, ValueError):
        return s or ""


@app.context_processor
def inject():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    try:
        store_name = get_settings().get("store_name")
    except sqlite3.Error:
        store_name = None
    return dict(csrf=session["csrf"], user=getattr(g, "user", None), store_name=store_name,
                UNITS=UNITS, MODES=MODES, today=date.today().isoformat())


# --------------------------------------------------------------------------
# Access control
# --------------------------------------------------------------------------
@app.before_request
def gate():
    if request.endpoint in (None, "static"):
        return None
    if request.method == "POST":
        token = request.form.get("csrf_token") or request.headers.get("X-CSRF")
        if not token or token != session.get("csrf"):
            abort(400, "Session expired - please reload the page and try again.")
    if request.endpoint == "login":
        return None
    if not session.get("uid"):
        return redirect(url_for("login", next=request.path))
    u = db().execute("SELECT * FROM users WHERE id=? AND active=1", (session["uid"],)).fetchone()
    if not u:
        session.clear()
        return redirect(url_for("login"))
    g.user = u
    if u["must_change"] and request.endpoint not in ("change_password", "logout"):
        return redirect(url_for("change_password"))
    return None


def owner_required(f):
    @wraps(f)
    def wrapper(*a, **k):
        if g.user["role"] != "owner":
            abort(403, "Only the owner can do this.")
        return f(*a, **k)
    return wrapper


@app.errorhandler(400)
@app.errorhandler(403)
@app.errorhandler(404)
def error_page(e):
    return render_template("error.html", e=e), e.code


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        name = request.form.get("username", "").strip()
        u = db().execute("SELECT * FROM users WHERE username=? AND active=1", (name,)).fetchone()
        if u and check_password_hash(u["pw_hash"], request.form.get("password", "")):
            session.clear()
            session["uid"] = u["id"]
            session["csrf"] = secrets.token_hex(16)
            audit("login", user=u["username"])
            db().commit()
            nxt = request.args.get("next", "")
            if not nxt.startswith("/") or nxt.startswith("//"):
                nxt = url_for("dashboard")
            return redirect(nxt)
        flash("Wrong username or password.", "error")
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/password", methods=["GET", "POST"])
def change_password():
    if request.method == "POST":
        f = request.form
        if not f.get("current") or not f.get("new") or not f.get("confirm"):
            flash("Current password, new password and confirm password are all mandatory.", "error")
        elif not check_password_hash(g.user["pw_hash"], f.get("current", "")):
            flash("Current password is wrong.", "error")
        elif password_error(f.get("new", "")):
            flash(password_error(f.get("new", "")), "error")
        elif f.get("new") == f.get("current"):
            flash("The new password must be different from the current password.", "error")
        elif f.get("new") != f.get("confirm"):
            flash("New password and confirmation do not match.", "error")
        else:
            db().execute("UPDATE users SET pw_hash=?, must_change=0 WHERE id=?",
                         (generate_password_hash(f["new"]), g.user["id"]))
            audit("password_changed")
            db().commit()
            flash("Password changed.", "ok")
            return redirect(url_for("dashboard"))
    return render_template("password.html")


# --------------------------------------------------------------------------
# Dashboard & Analytics
# --------------------------------------------------------------------------
@app.route("/")
def dashboard():
    d = db()
    today_dt = date.today()
    period = request.args.get("period", "date")
    if period not in ("date", "month", "year"):
        period = "date"

    sel_date = request.args.get("date") or today_dt.isoformat()
    sel_month = request.args.get("month") or today_dt.strftime("%Y-%m")
    sel_year = request.args.get("year") or today_dt.strftime("%Y")
    sel_cust = request.args.get("customer_id", type=int)

    if period == "date":
        date_cond, date_arg = "b.bill_date = ?", sel_date
        pay_cond, pay_arg = "pay_date = ?", sel_date
        period_label = dmy_filter(sel_date)
    elif period == "month":
        date_cond, date_arg = "substr(b.bill_date, 1, 7) = ?", sel_month
        pay_cond, pay_arg = "substr(pay_date, 1, 7) = ?", sel_month
        period_label = sel_month
    else:
        date_cond, date_arg = "substr(b.bill_date, 1, 4) = ?", sel_year
        pay_cond, pay_arg = "substr(pay_date, 1, 4) = ?", sel_year
        period_label = sel_year

    bill_where = [f"b.status='active'", date_cond]
    bill_args = [date_arg]
    pay_where = ["voided=0", pay_cond]
    pay_args = [pay_arg]
    if sel_cust:
        bill_where.append("b.customer_id = ?")
        bill_args.append(sel_cust)
        pay_where.append("customer_id = ?")
        pay_args.append(sel_cust)

    bw_sql = " AND ".join(bill_where)
    pw_sql = " AND ".join(pay_where)

    t = d.execute(
        f"SELECT COUNT(*) n, COALESCE(SUM(b.total),0) total, COALESCE(SUM(b.paid_now),0) paid "
        f"FROM bills b WHERE {bw_sql}", bill_args).fetchone()
    pay = d.execute(
        f"SELECT COALESCE(SUM(amount),0) a FROM payments WHERE {pw_sql}", pay_args).fetchone()["a"]
    outstanding = d.execute(
        "SELECT COALESCE(SUM(balance),0) s FROM (" + BALANCE_SQL + ") WHERE balance > 0").fetchone()["s"]

    prod_summary = d.execute(
        f"SELECT bi.name, bi.unit, SUM(CAST(bi.qty AS REAL)) qty, "
        f"SUM(bi.discount) disc, SUM(bi.amount) amount, COUNT(DISTINCT b.id) bills "
        f"FROM bill_items bi JOIN bills b ON b.id=bi.bill_id "
        f"WHERE {bw_sql} GROUP BY bi.name, bi.unit ORDER BY amount DESC", bill_args).fetchall()

    cust_products = d.execute(
        f"SELECT c.id cid, c.name cname, bi.name pname, bi.unit, "
        f"SUM(CAST(bi.qty AS REAL)) qty, SUM(bi.amount) amount, COUNT(DISTINCT b.id) bills "
        f"FROM bill_items bi JOIN bills b ON b.id=bi.bill_id JOIN customers c ON c.id=b.customer_id "
        f"WHERE {bw_sql} GROUP BY c.id, c.name, bi.name, bi.unit "
        f"ORDER BY c.name, amount DESC", bill_args).fetchall()

    recent = d.execute(
        f"SELECT b.*, c.name cname FROM bills b JOIN customers c ON c.id=b.customer_id "
        f"WHERE {bw_sql} ORDER BY b.id DESC LIMIT 10", bill_args).fetchall()

    customers_ = d.execute("SELECT id, name FROM customers WHERE active=1 ORDER BY name").fetchall()
    return render_template(
        "dashboard.html", t=t, collected=t["paid"] + pay, outstanding=outstanding,
        recent=recent, prod_summary=prod_summary, cust_products=cust_products,
        customers=customers_, period=period, sel_date=sel_date, sel_month=sel_month,
        sel_year=sel_year, sel_cust=sel_cust, period_label=period_label)


# --------------------------------------------------------------------------
# Products
# --------------------------------------------------------------------------
@app.route("/products")
def products():
    q = request.args.get("q", "").strip()
    show_all = request.args.get("all") == "1"
    sql = "SELECT * FROM products WHERE name LIKE ?"
    if not show_all:
        sql += " AND active=1"
    rows = db().execute(sql + " ORDER BY name", (f"%{q}%",)).fetchall()
    return render_template("products.html", rows=rows, q=q, show_all=show_all)


@app.route("/products/new", methods=["GET", "POST"])
@app.route("/products/<int:pid>/edit", methods=["GET", "POST"])
def product_form(pid=None):
    d = db()
    p = d.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone() if pid else None
    if pid and not p:
        abort(404)
    if request.method == "POST":
        f = request.form
        try:
            name = f.get("name", "").strip()
            unit = f.get("unit", "")
            if not name:
                raise ValueError("Product name is required")
            if unit not in UNITS:
                raise ValueError("Choose a unit")
            price = parse_money(f.get("price"))
            active = 1 if (f.get("active") or not p) else 0
            clash = d.execute("SELECT id FROM products WHERE name=? AND id IS NOT ?", (name, pid)).fetchone()
            if clash:
                raise ValueError("A product with this name already exists")
            if p:
                d.execute("UPDATE products SET name=?,unit=?,price=?,active=?,updated_at=? WHERE id=?",
                          (name, unit, price, active, now(), pid))
                audit("product_edit", f"{name} price {money(p['price'])} -> {money(price)}")
            else:
                d.execute("INSERT INTO products(name,unit,price,active,updated_at) VALUES(?,?,?,1,?)",
                          (name, unit, price, now()))
                audit("product_add", f"{name} {money(price)}/{unit}")
            d.commit()
            flash("Product saved.", "ok")
            return redirect(url_for("products"))
        except ValueError as e:
            flash(str(e), "error")
            p = dict(name=f.get("name", ""), unit=f.get("unit", "kg"), price=0, active=1,
                     price_text=f.get("price", ""), id=pid)
    return render_template("product_form.html", p=p, pid=pid)


@app.route("/products/prices", methods=["GET", "POST"])
def product_prices():
    d = db()
    if request.method == "POST":
        changed = 0
        try:
            for p in d.execute("SELECT * FROM products WHERE active=1").fetchall():
                raw = request.form.get(f"price_{p['id']}")
                if raw is None:
                    continue
                new = parse_money(raw)
                if new != p["price"]:
                    d.execute("UPDATE products SET price=?, updated_at=? WHERE id=?", (new, now(), p["id"]))
                    audit("price_change", f"{p['name']} {money(p['price'])} -> {money(new)}")
                    changed += 1
            d.commit()
            flash(f"Prices updated ({changed} changed).", "ok")
            return redirect(url_for("product_prices"))
        except ValueError as e:
            d.rollback()
            flash(str(e), "error")
    rows = d.execute("SELECT * FROM products WHERE active=1 ORDER BY name").fetchall()
    return render_template("product_prices.html", rows=rows)


# --------------------------------------------------------------------------
# Customers, ledger, payments
# --------------------------------------------------------------------------
def balance(d, cid):
    r = d.execute(BALANCE_SQL + " WHERE c.id=?", (cid,)).fetchone()
    return r["balance"] if r else 0


@app.route("/customers")
def customers():
    q = request.args.get("q", "").strip()
    show_all = request.args.get("all") == "1"
    rows = db().execute(
        "SELECT * FROM (" + BALANCE_SQL + ") WHERE (active=1 OR ?) AND (name LIKE ? OR mobile LIKE ?) ORDER BY name",
        (1 if show_all else 0, f"%{q}%", f"%{q}%")).fetchall()
    return render_template("customers.html", rows=rows, q=q, show_all=show_all)


@app.route("/customers/<int:cid>/delete", methods=["GET", "POST"])
@owner_required
def customer_delete(cid):
    """Owner only: permanently remove a customer together with all their bills and payments."""
    d = db()
    c = d.execute(BALANCE_SQL + " WHERE c.id=?", (cid,)).fetchone()
    if not c:
        abort(404)
    n_bills = d.execute("SELECT COUNT(*) n FROM bills WHERE customer_id=?", (cid,)).fetchone()["n"]
    n_pay = d.execute("SELECT COUNT(*) n FROM payments WHERE customer_id=?", (cid,)).fetchone()["n"]
    if request.method == "POST":
        if request.form.get("confirm_name", "").strip().lower() != c["name"].strip().lower():
            flash("The name you typed does not match, so nothing was deleted.", "error")
            return redirect(url_for("customer_delete", cid=cid))
        try:
            dest = make_backup(get_settings()["backup_folder"])
        except (OSError, sqlite3.Error) as e:
            flash(f"Safety backup failed ({e}), so nothing was deleted. Check the backup folder in Settings.", "error")
            return redirect(url_for("customer_delete", cid=cid))
        d.execute("DELETE FROM bill_items WHERE bill_id IN (SELECT id FROM bills WHERE customer_id=?)", (cid,))
        d.execute("DELETE FROM bills WHERE customer_id=?", (cid,))
        d.execute("DELETE FROM payments WHERE customer_id=?", (cid,))
        d.execute("DELETE FROM customer_prices WHERE customer_id=?", (cid,))
        d.execute("DELETE FROM customers WHERE id=?", (cid,))
        audit("customer_delete", f"{c['name']} (bills {n_bills}, payments {n_pay}); safety backup {dest}")
        d.commit()
        flash(f"{c['name']} was permanently deleted. A safety backup was saved first: {dest}", "ok")
        return redirect(url_for("customers"))
    return render_template("customer_delete.html", c=c, n_bills=n_bills, n_pay=n_pay)


@app.route("/customers/new", methods=["GET", "POST"])
@app.route("/customers/<int:cid>/edit", methods=["GET", "POST"])
def customer_form(cid=None):
    d = db()
    c = d.execute("SELECT * FROM customers WHERE id=?", (cid,)).fetchone() if cid else None
    if cid and not c:
        abort(404)
    if request.method == "POST":
        f = request.form
        try:
            name = f.get("name", "").strip()
            if not name:
                raise ValueError("Customer name is required")
            opening = parse_money(f.get("opening_balance"), allow_neg=True)
            vals = (name, f.get("mobile", "").strip(), f.get("address", "").strip(), opening)
            if c:
                d.execute("UPDATE customers SET name=?,mobile=?,address=?,opening_balance=?,active=? WHERE id=?",
                          vals + (1 if f.get("active") else 0, cid))
                audit("customer_edit", name)
            else:
                cur = d.execute("INSERT INTO customers(name,mobile,address,opening_balance) VALUES(?,?,?,?)", vals)
                cid = cur.lastrowid
                audit("customer_add", name)
            d.commit()
            flash("Customer saved.", "ok")
            return redirect(url_for("customer_detail", cid=cid))
        except ValueError as e:
            flash(str(e), "error")
            c = dict(name=f.get("name", ""), mobile=f.get("mobile", ""), address=f.get("address", ""),
                     opening_balance=0, opening_text=f.get("opening_balance", ""), active=1)
    return render_template("customer_form.html", c=c, cid=cid)


@app.route("/customers/<int:cid>")
def customer_detail(cid):
    d = db()
    c = d.execute(BALANCE_SQL + " WHERE c.id=?", (cid,)).fetchone()
    if not c:
        abort(404)
    ev = []
    if c["opening_balance"]:
        ev.append(dict(date="", at="", kind="opening", text="Opening balance",
                       debit=max(c["opening_balance"], 0), credit=max(-c["opening_balance"], 0)))
    for b in d.execute("SELECT * FROM bills WHERE customer_id=? AND status='active'", (cid,)):
        ev.append(dict(date=b["bill_date"], at=b["created_at"], kind="bill", id=b["id"],
                       text=f"Bill {bill_label(b)}", debit=b["total"], credit=b["paid_now"],
                       mode=b["pay_mode"] if b["paid_now"] else ""))
    for p in d.execute("SELECT * FROM payments WHERE customer_id=? AND voided=0", (cid,)):
        ev.append(dict(date=p["pay_date"], at=p["created_at"], kind="payment", id=p["id"],
                       text="Payment received" + (f" - {p['note']}" if p["note"] else ""),
                       debit=0, credit=p["amount"], mode=p["mode"]))
    ev.sort(key=lambda e: (e["date"], e["at"]))
    run = 0
    for e in ev:
        run += e["debit"] - e["credit"]
        e["balance"] = run
    return render_template("customer_detail.html", c=c, ledger=ev)


@app.route("/customers/<int:cid>/payment", methods=["GET", "POST"])
@app.route("/payments/<int:pid>/edit", methods=["GET", "POST"])
def payment_form(cid=None, pid=None):
    d = db()
    pay = None
    if pid:
        if g.user["role"] != "owner":
            abort(403, "Only the owner can edit payments.")
        pay = d.execute("SELECT * FROM payments WHERE id=? AND voided=0", (pid,)).fetchone()
        if not pay:
            abort(404)
        cid = pay["customer_id"]
    c = d.execute(BALANCE_SQL + " WHERE c.id=?", (cid,)).fetchone()
    if not c:
        abort(404)
    if request.method == "POST":
        f = request.form
        try:
            amount = parse_money(f.get("amount"))
            if amount <= 0:
                raise ValueError("Enter an amount greater than zero")
            mode = f.get("mode") if f.get("mode") in MODES else "Cash"
            pdate = parse_date(f.get("pay_date"))
            note = f.get("note", "").strip()
            if pay:
                d.execute("UPDATE payments SET amount=?,mode=?,pay_date=?,note=? WHERE id=?",
                          (amount, mode, pdate, note, pid))
                audit("payment_edit", f"{c['name']} {money(pay['amount'])} -> {money(amount)}")
            else:
                d.execute("INSERT INTO payments(customer_id,pay_date,amount,mode,note,created_by,created_at) "
                          "VALUES(?,?,?,?,?,?,?)", (cid, pdate, amount, mode, note, g.user["username"], now()))
                audit("payment_add", f"{c['name']} {money(amount)} {mode}")
            d.commit()
            flash("Payment saved.", "ok")
            return redirect(url_for("customer_detail", cid=cid))
        except ValueError as e:
            flash(str(e), "error")
    return render_template("payment_form.html", c=c, pay=pay)


@app.route("/payments/<int:pid>/void", methods=["POST"])
@owner_required
def payment_void(pid):
    d = db()
    p = d.execute("SELECT * FROM payments WHERE id=?", (pid,)).fetchone()
    if not p:
        abort(404)
    d.execute("UPDATE payments SET voided=1 WHERE id=?", (pid,))
    audit("payment_void", f"payment {pid} {money(p['amount'])}")
    d.commit()
    flash("Payment removed from the ledger.", "ok")
    return redirect(url_for("customer_detail", cid=p["customer_id"]))


@app.route("/api/customer/<int:cid>")
def api_customer(cid):
    d = db()
    rows = d.execute("SELECT product_id, rate FROM customer_prices WHERE customer_id=?", (cid,)).fetchall()
    return jsonify(balance=balance(d, cid), prices={str(r["product_id"]): r["rate"] for r in rows})


# --------------------------------------------------------------------------
# Bills
# --------------------------------------------------------------------------
def read_items(d, form):
    items = []
    names = form.getlist("item_name")
    qtys = form.getlist("qty")
    rates = form.getlist("rate")
    discs = form.getlist("discount")
    if len(discs) < len(names):
        discs += ["0"] * (len(names) - len(discs))
    for n, q, r, dc in zip(names, qtys, rates, discs):
        n, q, r, dc = n.strip(), q.strip(), r.strip(), dc.strip()
        if not n and not q:
            continue
        prod = d.execute("SELECT * FROM products WHERE name=? AND active=1", (n,)).fetchone()
        if not prod:
            raise ValueError(f"'{n}' is not in the product list. Add it under Products first.")
        qty = parse_qty(q)
        rate = parse_money(r if r else money_plain(prod["price"]))
        disc = parse_money(dc) if dc else 0
        items.append(dict(
            product_id=prod["id"], name=prod["name"], unit=prod["unit"], qty=qty,
            rate=rate, discount=disc, amount=line_amount(qty, rate, disc)))
    if not items:
        raise ValueError("Add at least one item")
    return items


def insert_bill(d, *, bill_no, version, customer_id, bill_date, items, paid, mode, note, prev, show_discount=1):
    subtotal, round_off, total = compute_totals(items)
    new_balance = prev + total - paid
    cur = d.execute(
        "INSERT INTO bills(bill_no,version,status,customer_id,bill_date,subtotal,round_off,total,paid_now,"
        "pay_mode,prev_balance,new_balance,note,created_by,created_at,show_discount) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (bill_no, version, "active", customer_id, bill_date, subtotal, round_off, total, paid,
         mode, prev, new_balance, note, g.user["username"], now(), 1 if show_discount else 0))
    bid = cur.lastrowid
    for i in items:
        d.execute(
            "INSERT INTO bill_items(bill_id,product_id,name,unit,qty,rate,discount,amount) VALUES(?,?,?,?,?,?,?,?)",
            (bid, i["product_id"], i["name"], i["unit"], str(i["qty"]), i["rate"], i["discount"], i["amount"]))
        d.execute(
            "INSERT INTO customer_prices(customer_id,product_id,rate,updated_at) VALUES(?,?,?,?) "
            "ON CONFLICT(customer_id,product_id) DO UPDATE SET rate=excluded.rate, updated_at=excluded.updated_at",
            (customer_id, i["product_id"], i["rate"], now()))
    return bid


def render_bill_form(bill=None, rows=None, cust_id=None, form=None):
    d = db()
    products_ = [dict(id=p["id"], name=p["name"], unit=p["unit"], price=p["price"])
                 for p in d.execute("SELECT * FROM products WHERE active=1 ORDER BY name")]
    customers_ = d.execute("SELECT id,name,mobile FROM customers WHERE active=1 ORDER BY name").fetchall()
    if bill:
        cust_id = bill["customer_id"]
    prev = bill["prev_balance"] if bill else (balance(d, cust_id) if cust_id else 0)
    prices = {str(r["product_id"]): r["rate"] for r in
              d.execute("SELECT product_id, rate FROM customer_prices WHERE customer_id=?", (cust_id,))} if cust_id else {}
    if rows is None:
        rows = []
    data = dict(products=products_, prices=prices, prev_balance=prev, rows=rows, editing=bool(bill))
    return render_template("bill_form.html", bill=bill, customers=customers_, cust_id=cust_id,
                           data=data, form=form or {})


@app.route("/bills/new", methods=["GET", "POST"])
def bill_new():
    d = db()
    if request.method == "POST":
        f = request.form
        try:
            cid = int(f.get("customer_id") or 0)
            cust = d.execute("SELECT * FROM customers WHERE id=? AND active=1", (cid,)).fetchone()
            if not cust:
                raise ValueError("Choose a customer")
            bill_date = parse_date(f.get("bill_date"))
            items = read_items(d, f)
            paid = parse_money(f.get("paid_now"))
            mode = f.get("pay_mode") if f.get("pay_mode") in MODES else "Cash"
            show_disc = 1 if f.get("show_discount") else 0
            for attempt in range(3):
                try:
                    prev = balance(d, cid)
                    last = int(d.execute("SELECT value FROM settings WHERE key='last_bill_no'").fetchone()["value"] or 0)
                    bill_no = max(d.execute("SELECT COALESCE(MAX(bill_no),0) m FROM bills").fetchone()["m"], last) + 1
                    d.execute("UPDATE settings SET value=? WHERE key='last_bill_no'", (str(bill_no),))
                    bid = insert_bill(
                        d, bill_no=bill_no, version=0, customer_id=cid, bill_date=bill_date,
                        items=items, paid=paid, mode=mode, note=f.get("note", "").strip(),
                        prev=prev, show_discount=show_disc)
                    break
                except sqlite3.IntegrityError:
                    d.rollback()
                    if attempt == 2:
                        raise
            nb = d.execute("SELECT * FROM bills WHERE id=?", (bid,)).fetchone()
            audit("bill_create", f"bill {bill_label(nb)} {cust['name']}")
            d.commit()
            flash(f"Bill {bill_label(nb)} saved.", "ok")
            return redirect(url_for("bill_view", bid=bid))
        except ValueError as e:
            d.rollback()
            flash(str(e), "error")
            discs = f.getlist("discount")
            names = f.getlist("item_name")
            if len(discs) < len(names):
                discs += ["0"] * (len(names) - len(discs))
            rows = [dict(name=n, qty=q, rate=r, discount=dc) for n, q, r, dc in
                    zip(names, f.getlist("qty"), f.getlist("rate"), discs)]
            return render_bill_form(rows=rows, cust_id=int(f.get("customer_id") or 0) or None, form=f)
    cid = request.args.get("customer", type=int)
    return render_bill_form(cust_id=cid)


@app.route("/bills/<int:bid>/edit", methods=["GET", "POST"])
@owner_required
def bill_edit(bid):
    d = db()
    b = d.execute("SELECT * FROM bills WHERE id=?", (bid,)).fetchone()
    if not b:
        abort(404)
    if b["status"] != "active":
        flash("Only the current version of an active bill can be edited.", "error")
        return redirect(url_for("bill_view", bid=bid))
    if request.method == "POST":
        f = request.form
        try:
            bill_date = parse_date(f.get("bill_date"))
            items = read_items(d, f)
            paid = parse_money(f.get("paid_now"))
            mode = f.get("pay_mode") if f.get("pay_mode") in MODES else "Cash"
            show_disc = 1 if f.get("show_discount") else 0
            d.execute("UPDATE bills SET status='superseded' WHERE id=?", (bid,))
            nid = insert_bill(
                d, bill_no=b["bill_no"], version=b["version"] + 1, customer_id=b["customer_id"],
                bill_date=bill_date, items=items, paid=paid, mode=mode,
                note=f.get("note", "").strip(), prev=b["prev_balance"], show_discount=show_disc)
            nb = d.execute("SELECT * FROM bills WHERE id=?", (nid,)).fetchone()
            audit("bill_edit", f"{bill_label(b)} -> {bill_label(nb)}: total {money(b['total'])} -> {money(nb['total'])}")
            d.commit()
            flash(f"Saved as new version {bill_label(nb)}. The old version is kept.", "ok")
            return redirect(url_for("bill_view", bid=nid))
        except ValueError as e:
            d.rollback()
            flash(str(e), "error")
            discs = f.getlist("discount")
            names = f.getlist("item_name")
            if len(discs) < len(names):
                discs += ["0"] * (len(names) - len(discs))
            rows = [dict(name=n, qty=q, rate=r, discount=dc) for n, q, r, dc in
                    zip(names, f.getlist("qty"), f.getlist("rate"), discs)]
            return render_bill_form(bill=b, rows=rows, form=f)
    rows = [dict(name=i["name"], qty=qty_str(i["qty"]), rate=money_plain(i["rate"]),
                 discount=money_plain(i["discount"]))
            for i in d.execute("SELECT * FROM bill_items WHERE bill_id=? ORDER BY id", (bid,))]
    return render_bill_form(bill=b, rows=rows)


@app.route("/bills/<int:bid>/cancel", methods=["POST"])
@owner_required
def bill_cancel(bid):
    d = db()
    b = d.execute("SELECT * FROM bills WHERE id=?", (bid,)).fetchone()
    if not b or b["status"] != "active":
        abort(404)
    d.execute("UPDATE bills SET status='cancelled', cancel_reason=? WHERE id=?",
              (request.form.get("reason", "").strip(), bid))
    audit("bill_cancel", f"{bill_label(b)} {money(b['total'])}")
    d.commit()
    flash(f"Bill {bill_label(b)} cancelled. It no longer counts in the balance.", "ok")
    return redirect(url_for("bill_view", bid=bid))


@app.route("/bills")
def bills():
    f = request.args
    where, args = ["1=1"], []
    if f.get("all") != "1":
        where.append("b.status != 'superseded'")
    if f.get("q"):
        q = f["q"].strip()
        num_q = re.sub(r"^RSGP\d{6}", "", q, flags=re.IGNORECASE).lstrip("0") or q
        where.append("(c.name LIKE ? OR CAST(b.bill_no AS TEXT) = ?)")
        args += [f"%{q}%", num_q]
    if f.get("from"):
        where.append("b.bill_date >= ?")
        args.append(f["from"])
    if f.get("to"):
        where.append("b.bill_date <= ?")
        args.append(f["to"])
    rows = db().execute(
        "SELECT b.*, c.name cname, (SELECT COUNT(*) FROM bill_items WHERE bill_id=b.id) n "
        "FROM bills b JOIN customers c ON c.id=b.customer_id WHERE " + " AND ".join(where) +
        " ORDER BY b.bill_date DESC, b.id DESC LIMIT 300", args).fetchall()
    return render_template("bills.html", rows=rows, f=f)


def bill_ctx(bid):
    d = db()
    b = d.execute("SELECT * FROM bills WHERE id=?", (bid,)).fetchone()
    if not b:
        abort(404)
    cust = d.execute("SELECT * FROM customers WHERE id=?", (b["customer_id"],)).fetchone()
    items = d.execute("SELECT * FROM bill_items WHERE bill_id=? ORDER BY id", (bid,)).fetchall()
    total_discount = sum(i["discount"] for i in items)
    return dict(
        bill=b, label=bill_label(b), settings=get_settings(), customer=cust,
        filename=bill_filename(b, cust["name"]), items=items,
        show_discount=bool(b["show_discount"]), total_discount=total_discount,
        versions=d.execute("SELECT * FROM bills WHERE bill_no=? ORDER BY version", (b["bill_no"],)).fetchall())


@app.route("/bills/<int:bid>")
def bill_view(bid):
    return render_template("bill_view.html", **bill_ctx(bid))


@app.route("/bills/<int:bid>/thermal")
def bill_thermal(bid):
    return render_template("bill_thermal.html", autoprint=request.args.get("print") == "1", **bill_ctx(bid))


@app.route("/bills/<int:bid>/pdf")
def bill_pdf(bid):
    ctx = bill_ctx(bid)
    buf = make_pdf(ctx)
    return send_file(buf, mimetype="application/pdf", download_name=ctx["filename"] + ".pdf",
                     as_attachment=request.args.get("download") == "1")


def make_pdf(ctx):
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_RIGHT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    b, c, s, items = ctx["bill"], ctx["customer"], ctx["settings"], ctx["items"]
    show_disc = ctx["show_discount"]
    ss = getSampleStyleSheet()
    base = ParagraphStyle("base", parent=ss["Normal"], fontName="Helvetica", fontSize=10, leading=13)
    right = ParagraphStyle("right", parent=base, alignment=TA_RIGHT)
    center = ParagraphStyle("center", parent=base, alignment=TA_CENTER)
    title = ParagraphStyle("title", parent=center, fontName="Helvetica-Bold", fontSize=20, leading=24)
    red = ParagraphStyle("red", parent=center, fontName="Helvetica-Bold", fontSize=14, textColor=colors.red)
    bold = ParagraphStyle("bold", parent=base, fontName="Helvetica-Bold")
    boldr = ParagraphStyle("boldr", parent=right, fontName="Helvetica-Bold")
    P = lambda t, st=base: Paragraph(escape(str(t)), st)  # noqa: E731

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm,
                            topMargin=15 * mm, bottomMargin=15 * mm, title=ctx["filename"])
    el = []
    if b["status"] != "active":
        el.append(P("CANCELLED" if b["status"] == "cancelled" else "OLD VERSION - SUPERSEDED", red))
    el.append(P(s["store_name"], title))
    if s["store_address"]:
        el.append(P(s["store_address"], center))
    if s["store_mobile"]:
        el.append(P("Mobile: " + s["store_mobile"], center))
    if s.get("show_gst") == "1" and s.get("gst_number"):
        el.append(P("GSTIN: " + s["gst_number"], center))
    el.append(Spacer(1, 6 * mm))

    cust_lines = [f"<b>Customer:</b> {escape(c['name'])}"]
    if c["mobile"]:
        cust_lines.append(f"<b>Mobile:</b> {escape(c['mobile'])}")
    if c["address"]:
        cust_lines.append(f"<b>Address:</b> {escape(c['address'])}")
    meta = Table([[Paragraph(f"<b>Bill No:</b> {escape(ctx['label'])}<br/><b>Date:</b> {dmy_filter(b['bill_date'])}", base),
                   Paragraph("<br/>".join(cust_lines), base)]], colWidths=[75 * mm, 105 * mm])
    meta.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                              ("BOX", (0, 0), (-1, -1), 0.6, colors.grey),
                              ("LINEAFTER", (0, 0), (0, 0), 0.6, colors.grey)]))
    el += [meta, Spacer(1, 5 * mm)]

    if show_disc:
        rows = [[P("#", bold), P("Item", bold), P("Qty", boldr), P("Unit", bold),
                 P("Rate", boldr), P("Discount", boldr), P("Amount", boldr)]]
        for n, i in enumerate(items, 1):
            rows.append([P(n), P(i["name"]), P(qty_str(i["qty"]), right), P(i["unit"]),
                         P(money(i["rate"]), right), P(money(i["discount"]), right), P(money(i["amount"]), right)])
        col_widths = [10 * mm, 58 * mm, 20 * mm, 17 * mm, 24 * mm, 23 * mm, 28 * mm]
    else:
        rows = [[P("#", bold), P("Item", bold), P("Qty", boldr), P("Unit", bold), P("Rate", boldr), P("Amount", boldr)]]
        for n, i in enumerate(items, 1):
            rows.append([P(n), P(i["name"]), P(qty_str(i["qty"]), right), P(i["unit"]),
                         P(money(i["rate"]), right), P(money(i["amount"]), right)])
        col_widths = [10 * mm, 70 * mm, 25 * mm, 20 * mm, 25 * mm, 30 * mm]

    t = Table(rows, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8eef5")),
                           ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
                           ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    el += [t, Spacer(1, 4 * mm)]

    tot = [[P("Subtotal", right), P(money(b["subtotal"]), right)]]
    if show_disc and ctx["total_discount"] > 0:
        tot.insert(0, [P("Total Discount", right), P("- " + money(ctx["total_discount"]), right)])
    if b["round_off"]:
        tot.append([P("Round off", right), P(("+" if b["round_off"] > 0 else "") + money(b["round_off"]), right)])
    tot.append([P("Bill Total (Rs.)", boldr), P(money(b["total"]), boldr)])
    tt = Table(tot, colWidths=[50 * mm, 35 * mm], hAlign="RIGHT")
    tt.setStyle(TableStyle([("LINEABOVE", (0, -1), (-1, -1), 0.8, colors.black)]))
    el += [tt, Spacer(1, 5 * mm)]

    due_label = "Balance due" if b["new_balance"] > 0 else ("Advance (credit)" if b["new_balance"] < 0 else "Balance")
    paid_label = "Paid now" + (f" ({b['pay_mode']})" if b["paid_now"] and b["pay_mode"] else "")
    summ = [[P("ACCOUNT SUMMARY", bold), ""],
            [P("Previous balance"), P(money(b["prev_balance"]), right)],
            [P(f"This bill ({len(items)} item{'s' if len(items) != 1 else ''})"), P(money(b["total"]), right)],
            [P(paid_label), P("- " + money(b["paid_now"]), right)],
            [P(due_label + " (Rs.)", bold), P(money(abs(b["new_balance"])), boldr)]]
    st = Table(summ, colWidths=[60 * mm, 35 * mm], hAlign="LEFT")
    st.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, colors.black),
                            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8eef5")),
                            ("SPAN", (0, 0), (1, 0)),
                            ("LINEABOVE", (0, -1), (-1, -1), 0.6, colors.black)]))
    el.append(st)
    if b["note"]:
        el += [Spacer(1, 4 * mm), P("Note: " + b["note"])]
    if s["bill_footer"]:
        el += [Spacer(1, 10 * mm), P(s["bill_footer"], center)]
    doc.build(el)
    buf.seek(0)
    return buf


# --------------------------------------------------------------------------
# Reports (owner only)
# --------------------------------------------------------------------------
@app.route("/reports")
@owner_required
def reports():
    d = db()
    kind = request.args.get("kind", "daily")
    today = date.today()
    frm = request.args.get("from") or (today - timedelta(days=29)).isoformat()
    to = request.args.get("to") or today.isoformat()
    ctx = dict(kind=kind, frm=frm, to=to)
    if kind == "outstanding":
        rows = d.execute("SELECT * FROM (" + BALANCE_SQL + ") WHERE active=1 AND balance != 0 "
                         "ORDER BY balance DESC").fetchall()
        ctx.update(rows=rows, total_due=sum(r["balance"] for r in rows if r["balance"] > 0))
    elif kind == "products":
        rows = d.execute(
            "SELECT bi.name, bi.unit, SUM(CAST(bi.qty AS REAL)) q, SUM(bi.amount) a, COUNT(DISTINCT b.id) n "
            "FROM bill_items bi JOIN bills b ON b.id=bi.bill_id "
            "WHERE b.status='active' AND b.bill_date BETWEEN ? AND ? "
            "GROUP BY bi.name, bi.unit ORDER BY a DESC", (frm, to)).fetchall()
        ctx.update(rows=rows, total=sum(r["a"] for r in rows))
    else:
        days = {}
        for r in d.execute("SELECT bill_date dt, COUNT(*) n, SUM(total) t, SUM(paid_now) p FROM bills "
                           "WHERE status='active' AND bill_date BETWEEN ? AND ? GROUP BY bill_date", (frm, to)):
            days[r["dt"]] = dict(dt=r["dt"], n=r["n"], sales=r["t"], at_bill=r["p"], later=0)
        for r in d.execute("SELECT pay_date dt, SUM(amount) a FROM payments WHERE voided=0 "
                           "AND pay_date BETWEEN ? AND ? GROUP BY pay_date", (frm, to)):
            days.setdefault(r["dt"], dict(dt=r["dt"], n=0, sales=0, at_bill=0, later=0))["later"] = r["a"]
        rows = sorted(days.values(), key=lambda x: x["dt"], reverse=True)
        ctx.update(rows=rows, tot=dict(n=sum(r["n"] for r in rows), sales=sum(r["sales"] for r in rows),
                                       at_bill=sum(r["at_bill"] for r in rows), later=sum(r["later"] for r in rows)))
    return render_template("reports.html", **ctx)


# --------------------------------------------------------------------------
# Settings, users, backup & DB import
# --------------------------------------------------------------------------
@app.route("/settings", methods=["GET", "POST"])
@owner_required
def settings():
    d = db()
    if request.method == "POST":
        for k in ("store_name", "store_address", "store_mobile", "gst_number", "bill_footer", "backup_folder"):
            if k in request.form:
                d.execute(
                    "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (k, request.form[k].strip()))
        show_gst = "1" if request.form.get("show_gst") else "0"
        d.execute(
            "INSERT INTO settings(key,value) VALUES('show_gst',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (show_gst,))
        audit("settings_changed")
        d.commit()
        flash("Settings saved.", "ok")
        return redirect(url_for("settings"))
    return render_template("settings.html", s=get_settings())


@app.route("/users", methods=["GET", "POST"])
@owner_required
def users():
    d = db()
    if request.method == "POST":
        f = request.form
        act = f.get("action")
        try:
            if act == "add":
                name, pw = f.get("username", "").strip(), f.get("password", "")
                role = "staff" if f.get("role") != "owner" else "owner"
                if not name or not pw:
                    raise ValueError("Username and password are mandatory")
                if password_error(pw):
                    raise ValueError(password_error(pw))
                d.execute("INSERT INTO users(username,pw_hash,role,must_change) VALUES(?,?,?,1)",
                          (name, generate_password_hash(pw), role))
                audit("user_add", f"{name} ({role})")
            elif act == "toggle":
                uid = int(f.get("uid"))
                if uid == g.user["id"]:
                    raise ValueError("You cannot deactivate your own account")
                d.execute("UPDATE users SET active = 1 - active WHERE id=?", (uid,))
                audit("user_toggle", str(uid))
            elif act == "reset":
                pw = f.get("password", "")
                if not pw:
                    raise ValueError("Password is mandatory")
                if password_error(pw):
                    raise ValueError(password_error(pw))
                d.execute("UPDATE users SET pw_hash=?, must_change=1 WHERE id=?",
                          (generate_password_hash(pw), int(f.get("uid"))))
                audit("user_reset", f.get("uid"))
            d.commit()
            flash("Saved.", "ok")
        except sqlite3.IntegrityError:
            d.rollback()
            flash("That username already exists", "error")
        except ValueError as e:
            d.rollback()
            flash(str(e), "error")
        return redirect(url_for("users"))
    return render_template("users.html", rows=d.execute("SELECT * FROM users ORDER BY username").fetchall())


def list_backups(folder):
    try:
        files = [f for f in os.listdir(folder) if f.startswith("billing_backup_") and f.endswith(".db")]
    except OSError:
        return []
    out = []
    for f in sorted(files, reverse=True)[:15]:
        st = os.stat(os.path.join(folder, f))
        out.append(dict(name=f, size_kb=max(1, st.st_size // 1024),
                        when=datetime.fromtimestamp(st.st_mtime).strftime("%d-%m-%Y %H:%M")))
    return out


def make_backup(folder):
    os.makedirs(folder, exist_ok=True)
    stamp = datetime.now().strftime("billing_backup_%Y%m%d_%H%M%S")
    dest, n = os.path.join(folder, stamp + ".db"), 1
    while os.path.exists(dest):
        n += 1
        dest = os.path.join(folder, f"{stamp}_{n}.db")
    out = sqlite3.connect(dest)
    try:
        db().backup(out)
    finally:
        out.close()
    return dest


@app.route("/backup", methods=["GET", "POST"])
def backup():
    folder = get_settings()["backup_folder"]
    if request.method == "POST":
        try:
            dest = make_backup(folder)
            audit("backup", dest)
            db().commit()
            flash(f"Backup created: {dest}", "ok")
        except (OSError, sqlite3.Error) as e:
            flash(f"Backup failed: {e}. Check the backup folder in Settings.", "error")
        return redirect(url_for("backup"))
    return render_template("backup.html", folder=folder, files=list_backups(folder))


@app.route("/backup/import", methods=["POST"])
@owner_required
def backup_import():
    """Owner only: validate and restore a .db backup file safely."""
    fh = request.files.get("db_file")
    if not fh or not fh.filename or not fh.filename.lower().endswith(".db"):
        flash("Please choose a valid .db backup file.", "error")
        return redirect(url_for("backup"))

    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as tmp:
            tmp_path = tmp.name
            fh.save(tmp_path)

        # Verify SQLite integrity & required tables
        src = sqlite3.connect(tmp_path)
        try:
            tables = {r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            required = {"settings", "users", "products", "customers", "bills", "bill_items"}
            if not required.issubset(tables):
                raise ValueError("This file is not a valid billing database backup.")

            # Take a safety backup of the current database before overwriting
            safety = make_backup(get_settings()["backup_folder"])
            src.backup(db())
        finally:
            src.close()

        init_db()  # ensure any newer columns exist on restored older backups
        audit("backup_import", f"Restored {fh.filename} (safety copy: {safety})")
        db().commit()
        flash(f"Database restored from {fh.filename}. Safety backup saved at: {safety}", "ok")
    except (ValueError, OSError, sqlite3.Error) as e:
        flash(f"Import failed: {e}", "error")
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.remove(tmp_path)
    return redirect(url_for("backup"))


@app.route("/backup/download/<name>")
def backup_download(name):
    folder = get_settings()["backup_folder"]
    if not (name.startswith("billing_backup_") and name.endswith(".db")):
        abort(404)
    return send_from_directory(folder, name, as_attachment=True)


# --------------------------------------------------------------------------
init_db()
app.secret_key = secret_key()

if __name__ == "__main__":
    url = "http://127.0.0.1:5000"
    print(f"\n  Billing software running at {url}\n  Keep this window open while you use it. Press Ctrl+C to stop.\n")
    threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)