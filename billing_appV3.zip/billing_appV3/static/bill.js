(function () {
  const data = JSON.parse(document.getElementById('bill-data').textContent);
  const byName = {}, byId = {};
  data.products.forEach(p => { byName[p.name.toLowerCase()] = p; byId[p.id] = p; });
  let custPrices = data.prices || {};
  let prev = data.prev_balance || 0;
  const rowsEl = document.getElementById('rows');
  const useLast = document.getElementById('use_last');
  const csrf = document.querySelector('input[name=csrf_token]').value;

  function indian(n) {
    let s = String(n);
    if (s.length <= 3) return s;
    let last3 = s.slice(-3), rest = s.slice(0, -3), g = [];
    while (rest.length > 2) { g.unshift(rest.slice(-2)); rest = rest.slice(0, -2); }
    if (rest) g.unshift(rest);
    return g.concat([last3]).join(',');
  }
  function fmt(p) {
    const neg = p < 0; p = Math.abs(p);
    return (neg ? '-' : '') + indian(Math.floor(p / 100)) + '.' + String(p % 100).padStart(2, '0');
  }
  const plain = p => (p / 100).toFixed(2);
  const toPaise = s => { const v = parseFloat(String(s).replace(/,/g, '')); return isNaN(v) ? 0 : Math.round(v * 100); };

  function rateFor(p) {
    const c = custPrices[p.id];
    return (useLast.checked && c != null) ? c : p.price;
  }
  function setHint(tr) {
    const p = tr._p, hint = tr.querySelector('.hint');
    hint.textContent = '';
    if (!p) return;
    const c = custPrices[p.id];
    if (c != null && toPaise(tr.querySelector('.rate').value) !== c) {
      hint.textContent = 'last for customer: ' + fmt(c) + ' (click to use)';
      hint.onclick = () => { tr.querySelector('.rate').value = plain(c); recalc(); setHint(tr); };
    }
  }
  function applyProduct(tr, keepRate) {
    const nm = tr.querySelector('.nm').value.trim().toLowerCase();
    const p = byName[nm] || null;
    tr._p = p;
    tr.querySelector('.unit').textContent = p ? p.unit : '';
    if (p && !keepRate) tr.querySelector('.rate').value = plain(rateFor(p));
    setHint(tr);
  }

  function addRow(r) {
    const tr = document.createElement('tr');
    tr.innerHTML = '<td><input name="item_name" list="plist" class="nm"></td>' +
      '<td><input name="qty" inputmode="decimal" class="qty"></td><td class="unit"></td>' +
      '<td><input name="rate" inputmode="decimal" class="rate"><div class="hint"></div></td>' +
      '<td><input name="discount" inputmode="decimal" class="disc" placeholder="0.00"></td>' +
      '<td class="amt right">0.00</td><td><button type="button" class="alt small x" title="Remove row">x</button></td>';
    rowsEl.appendChild(tr);
    if (r) {
      tr.querySelector('.nm').value = r.name || '';
      tr.querySelector('.qty').value = r.qty || '';
      tr.querySelector('.rate').value = r.rate || '';
      tr.querySelector('.disc').value = r.discount || '';
      applyProduct(tr, true);
    }
    tr.addEventListener('input', e => {
      if (e.target.classList.contains('nm')) {
        const before = tr._p;
        applyProduct(tr, false);
        if (tr._p && !before && rowsEl.lastElementChild === tr) addRow();
      } else if (e.target.classList.contains('rate')) setHint(tr);
      recalc();
    });
    tr.querySelector('.x').onclick = () => { if (rowsEl.children.length > 1) { tr.remove(); recalc(); } };
    return tr;
  }

  function recalc() {
    let sub = 0, totalDisc = 0, cnt = 0;
    rowsEl.querySelectorAll('tr').forEach(tr => {
      const qty = parseFloat(tr.querySelector('.qty').value);
      const rate = toPaise(tr.querySelector('.rate').value);
      const disc = Math.max(0, toPaise(tr.querySelector('.disc').value));
      let amt = 0;
      if (!isNaN(qty) && qty > 0 && tr._p) {
        const gross = Math.round(Math.round(qty * 1000) * rate / 1000);
        amt = Math.max(0, gross - disc);
        totalDisc += disc;
        cnt++;
      }
      tr.querySelector('.amt').textContent = fmt(amt);
      sub += amt;
    });
    const total = Math.floor((sub + 50) / 100) * 100;
    const paid = toPaise(document.getElementById('paid').value);
    const nb = prev + total - paid;
    const discEl = document.getElementById('t_disc');
    if (discEl) discEl.textContent = fmt(totalDisc);
    document.getElementById('t_sub').textContent = fmt(sub);
    document.getElementById('t_rnd').textContent = fmt(total - sub);
    document.getElementById('t_tot').textContent = fmt(total);
    document.getElementById('t_cnt').textContent = cnt;
    document.getElementById('t_prev').textContent = fmt(prev);
    document.getElementById('t_nb').textContent = fmt(Math.abs(nb));
    document.getElementById('t_nbl').textContent = nb > 0 ? 'Balance due' : (nb < 0 ? 'Advance (credit)' : 'Balance');
  }

  document.getElementById('paid').addEventListener('input', recalc);
  document.getElementById('addrow').onclick = () => addRow().querySelector('.nm').focus();

  useLast.addEventListener('change', () => {
    rowsEl.querySelectorAll('tr').forEach(tr => {
      if (tr._p) { tr.querySelector('.rate').value = plain(rateFor(tr._p)); setHint(tr); }
    });
    recalc();
  });

  const cust = document.getElementById('customer');
  if (cust) cust.addEventListener('change', () => {
    if (!cust.value) { custPrices = {}; prev = 0; recalc(); return; }
    fetch('/api/customer/' + cust.value, { headers: { 'X-CSRF': csrf } })
      .then(r => r.json()).then(j => {
        custPrices = j.prices || {}; prev = j.balance || 0;
        rowsEl.querySelectorAll('tr').forEach(tr => {
          if (tr._p && useLast.checked) tr.querySelector('.rate').value = plain(rateFor(tr._p));
          setHint(tr);
        });
        recalc();
      });
  });

  document.getElementById('billform').addEventListener('keydown', e => {
    if (e.key !== 'Enter' || e.target.tagName === 'BUTTON') return;
    e.preventDefault();
    const fields = Array.from(document.querySelectorAll('#billform input:not([type=hidden]):not([type=checkbox]), #billform select'));
    const i = fields.indexOf(e.target);
    if (i >= 0 && i < fields.length - 1) fields[i + 1].focus();
  });

  (data.rows && data.rows.length ? data.rows : [{}, {}, {}]).forEach(r => addRow(r.name ? r : null));
  if (data.rows && data.rows.length) addRow();
  recalc();
})();