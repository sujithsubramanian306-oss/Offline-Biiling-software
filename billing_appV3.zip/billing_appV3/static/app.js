/* Small helpers: count-up numbers on the dashboard, show/hide password, live password rules */
(function () {
  // ---- count-up for dashboard figures (final value is already in the HTML) ----
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  document.querySelectorAll('[data-count]').forEach(function (el) {
    var target = parseFloat(el.getAttribute('data-count'));
    if (isNaN(target) || reduce) return;
    var dec = parseInt(el.getAttribute('data-dec') || '0', 10);
    var start = null, dur = 900, original = el.textContent;
    function fmt(v) { return v.toLocaleString('en-IN', { minimumFractionDigits: dec, maximumFractionDigits: dec }); }
    function step(ts) {
      if (start === null) start = ts;
      var p = Math.min((ts - start) / dur, 1), e = 1 - Math.pow(1 - p, 3);
      el.textContent = p < 1 ? fmt(target * e) : original;
      if (p < 1) requestAnimationFrame(step);
    }
    el.textContent = fmt(0);
    requestAnimationFrame(step);
  });

  // ---- show / hide password ----
  document.querySelectorAll('.pwwrap .eye').forEach(function (b) {
    b.addEventListener('click', function () {
      var inp = b.parentNode.querySelector('input');
      var show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      b.textContent = show ? 'Hide' : 'Show';
    });
  });

  // ---- live password rules: forms with data-pwform ----
  var tests = {
    len: function (v) { return v.length >= 6; },
    upper: function (v) { return /[A-Z]/.test(v); },
    lower: function (v) { return /[a-z]/.test(v); },
    digit: function (v) { return /[0-9]/.test(v); },
    symbol: function (v) { return /[^A-Za-z0-9]/.test(v); }
  };
  document.querySelectorAll('form[data-pwform]').forEach(function (form) {
    var np = form.querySelector('[data-newpw]'), cf = form.querySelector('[data-confirmpw]');
    var list = form.querySelector('.rules'), msg = form.querySelector('.matchmsg');
    var btn = form.querySelector('button[type=submit], button:not([type])');
    function check() {
      var v = np.value, all = true;
      if (list) list.querySelectorAll('li').forEach(function (li) {
        var ok = tests[li.getAttribute('data-rule')](v);
        li.classList.toggle('ok', ok);
        if (!ok) all = false;
      });
      var match = true;
      if (cf) {
        match = cf.value.length > 0 && cf.value === v;
        if (msg) {
          msg.textContent = cf.value.length === 0 ? '' : (match ? 'Passwords match' : 'Passwords do not match');
          msg.className = 'matchmsg ' + (cf.value.length === 0 ? '' : (match ? 'ok' : 'bad'));
        }
      }
      return all && match;
    }
    np.addEventListener('input', check);
    if (cf) cf.addEventListener('input', check);
    form.addEventListener('submit', function (e) {
      var empty = false;
      form.querySelectorAll('input[required]').forEach(function (i) { if (!i.value.trim()) empty = true; });
      if (empty || !check()) {
        e.preventDefault();
        if (!empty) { np.focus(); }
        form.classList.remove('shake'); void form.offsetWidth; form.classList.add('shake');
      }
    });
    check();
  });
})();
