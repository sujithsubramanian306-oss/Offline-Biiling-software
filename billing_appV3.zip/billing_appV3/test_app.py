"""End-to-end checks. Run:  python test_app.py   (uses a temporary database)"""
import os
import re
import sqlite3
import tempfile

tmp = tempfile.mkdtemp()
os.environ["BILLING_DATA_DIR"] = tmp
import app as A  # noqa: E402

c = A.app.test_client()
A.app.config["TESTING"] = True


def csrf(client=c):
    with client.session_transaction() as s:
        return s.get("csrf", "")


def post(url, data, client=c, **kw):
    d = dict(data)
    d["csrf_token"] = csrf(client)
    return client.post(url, data=d, **kw)


def check(cond, msg):
    print(("PASS  " if cond else "FAIL  ") + msg)
    if not cond:
        raise SystemExit(1)


# --- login & forced password change
r = c.get("/login")
r = post("/login", dict(username="owner", password="owner123"))
check(r.status_code == 302, "owner can log in with default password")
r = c.get("/")
check(r.status_code == 302 and "/password" in r.headers["Location"], "default password forces a change")
for label, form, expect in [
    ("empty fields", dict(current="", new="", confirm=""), b"mandatory"),
    ("wrong current password", dict(current="nope", new="Secret@99", confirm="Secret@99"), b"Current password is wrong"),
    ("no capital letter", dict(current="owner123", new="secret@99", confirm="secret@99"), b"a capital letter"),
    ("no small letter", dict(current="owner123", new="SECRET@99", confirm="SECRET@99"), b"a small letter"),
    ("no number", dict(current="owner123", new="Secret@xx", confirm="Secret@xx"), b"a number"),
    ("no symbol", dict(current="owner123", new="Secret99", confirm="Secret99"), b"a symbol"),
    ("too short", dict(current="owner123", new="Se@9", confirm="Se@9"), b"at least 6 characters"),
    ("confirm does not match", dict(current="owner123", new="Secret@99", confirm="Secret@98"), b"do not match"),
]:
    r = post("/password", form, follow_redirects=True)
    check(expect in r.data, f"password change rejected: {label}")
check(c.get("/").status_code == 302, "still forced to change password after the rejected attempts")
r = c.get("/password")
check(r.data.count(b'class="req"') == 3, "current / new / confirm password are marked mandatory (*)")
post("/password", dict(current="owner123", new="Secret@99", confirm="Secret@99"))
check(c.get("/").status_code == 200, "dashboard opens after a valid password change")

# --- products & customers
post("/products/new", dict(name="Tomato", unit="kg", price="50"))
post("/products/new", dict(name="Rice", unit="kg", price="60.50"))
post("/products/new", dict(name="Soap", unit="piece", price="35"))
r = post("/customers/new", dict(name="Ravi Traders", mobile="9876543210", address="Main Rd", opening_balance="100"))
check(r.status_code == 302, "customer created")
with A.app.app_context():
    d = A.connect()
    cid = d.execute("SELECT id FROM customers").fetchone()["id"]
    check(d.execute("SELECT price FROM products WHERE name='Tomato'").fetchone()["price"] == 5000, "price stored as paise")
    d.close()


def new_bill(items, paid="0", mode="Cash", date="2026-11-22"):
    d = dict(customer_id=str(cid), bill_date=date, paid_now=paid, pay_mode=mode, note="")
    d["item_name"] = [i[0] for i in items]
    d["qty"] = [i[1] for i in items]
    d["rate"] = [i[2] for i in items]
    return post("/bills/new", d)


# --- the example from the brief: 0.5 kg at Rs.50/kg = Rs.25
r = new_bill([("Tomato", "0.5", "50")], paid="10")
check(r.status_code == 302, "bill 1 saved")
with A.app.app_context():
    d = A.connect()
    b = d.execute("SELECT * FROM bills WHERE bill_no=1").fetchone()
    check(b["subtotal"] == 2500 and b["total"] == 2500, "0.5 kg x Rs.50 = Rs.25.00")
    check(b["prev_balance"] == 10000 and b["new_balance"] == 10000 + 2500 - 1000, "balance = prev 100 + 25 - paid 10 = 115")
    d.close()

# --- round off to nearest rupee (half up): 1.25 kg x 60.50 = 75.625 -> 75.63; + 0.5 x 50 = 25 -> 100.63 -> Rs.101
r = new_bill([("Rice", "1.25", "60.50"), ("Tomato", "0.5", "50")], paid="0")
with A.app.app_context():
    d = A.connect()
    b2 = d.execute("SELECT * FROM bills WHERE bill_no=2").fetchone()
    check(b2["subtotal"] == 10063 and b2["total"] == 10100 and b2["round_off"] == 37, "round-off to nearest rupee")
    check(b2["prev_balance"] == 11500, "second bill carries the previous balance (115.00)")
    check(b2["new_balance"] == 21600, "new balance 216.00")
    item = d.execute("SELECT * FROM bill_items WHERE bill_id=? AND name='Rice'", (b2["id"],)).fetchone()
    check(item["qty"] == "1.25" and item["amount"] == 7563, "line amount rounded to paise")
    cp = d.execute("SELECT rate FROM customer_prices WHERE customer_id=?", (cid,)).fetchall()
    check(len(cp) == 2, "customer-specific rates remembered")
    d.close()

# --- bad input is rejected, nothing saved
r = new_bill([("Mango", "1", "10")])
check(b"not in the product list" in r.data, "unknown product rejected")
r = new_bill([("Tomato", "0.5555", "50")])
check(b"at most 3 decimal" in r.data, "qty with >3 decimals rejected")

# --- customer payment, ledger
r = post(f"/customers/{cid}/payment", dict(amount="116", mode="UPI", pay_date="2026-11-22", note="part"))
with A.app.app_context():
    d = A.connect()
    check(A.balance(d, cid) == 21600 - 11600, "payment reduces the balance (100.00 left)")
    d.close()
page = c.get(f"/customers/{cid}").data.decode()
check("Bill 1" in page and "Bill 2" in page and "Payment received" in page and "Opening balance" in page, "ledger shows opening, bills, payment")

# --- version control: edit bill 2 -> 2_v1, old kept
with A.app.app_context():
    d = A.connect()
    b2id = d.execute("SELECT id FROM bills WHERE bill_no=2").fetchone()["id"]
    d.close()
r = post(f"/bills/{b2id}/edit", dict(customer_id=str(cid), bill_date="2026-11-22", paid_now="0", pay_mode="Cash", note="",
                                      item_name=["Rice"], qty=["1"], rate=["58"]))
check(r.status_code == 302, "edit saved")
with A.app.app_context():
    d = A.connect()
    rows = d.execute("SELECT version,status,total FROM bills WHERE bill_no=2 ORDER BY version").fetchall()
    check([(x["version"], x["status"]) for x in rows] == [(0, "superseded"), (1, "active")], "old version kept, new _v1 is active")
    check(rows[1]["total"] == 5800, "new version total Rs.58")
    check(A.balance(d, cid) == 10000 + 2500 - 1000 + 5800 - 11600, "balance uses only the active version")
    new_id = d.execute("SELECT id FROM bills WHERE bill_no=2 AND version=1").fetchone()["id"]
    d.close()
check("2_v1" in c.get(f"/bills/{new_id}").data.decode(), "bill label shows 2_v1")

# --- outputs
r = c.get(f"/bills/{new_id}/thermal")
check(r.status_code == 200 and b"80mm" in r.data and b"BALANCE DUE" in r.data, "80mm thermal page renders")
r = c.get(f"/bills/{new_id}/pdf")
check(r.status_code == 200 and r.data[:4] == b"%PDF", "A4 PDF generated")
open(os.path.join(tmp, "sample_bill.pdf"), "wb").write(r.data)

# --- cancel
r = post(f"/bills/{new_id}/cancel", dict(reason="test"))
with A.app.app_context():
    d = A.connect()
    check(A.balance(d, cid) == 10000 + 2500 - 1000 - 11600, "cancelled bill no longer counts")
    d.close()

# --- reports, backup, settings
for k in ("daily", "outstanding", "products"):
    check(c.get(f"/reports?kind={k}").status_code == 200, f"report {k} renders")
r = post("/backup", {})
files = os.listdir(os.path.join(tmp, "backups"))
check(len(files) == 1, "manual backup file created")
bk = sqlite3.connect(os.path.join(tmp, "backups", files[0]))
check(bk.execute("SELECT COUNT(*) FROM bills").fetchone()[0] == 3, "backup contains the data")
post("/settings", dict(store_name="Rajeshwari Stores", store_address="1 Main St", store_mobile="99999", bill_footer="Thanks", backup_folder=os.path.join(tmp, "backups")))
check(b"Rajeshwari Stores" in c.get(f"/bills/{new_id}/thermal").data, "store name on bill")

# --- staff restrictions
r = post("/users", dict(action="add", username="weak", password="staffpw1", role="staff"), follow_redirects=True)
check(b"a capital letter" in r.data, "weak password rejected when adding a user")
post("/users", dict(action="add", username="staff1", password="Staff@pw1", role="staff"))
s = A.app.test_client()
s.get("/login")
post("/login", dict(username="staff1", password="Staff@pw1"), client=s)
post("/password", dict(current="Staff@pw1", new="Staff@pw2", confirm="Staff@pw2"), client=s)
check(s.get("/settings").status_code == 403, "staff cannot open settings")
check(s.get("/reports").status_code == 403, "staff cannot open reports")
check(s.get(f"/bills/{b2id}/edit").status_code == 403, "staff cannot edit bills")
check(s.get("/bills/new").status_code == 200, "staff can create bills")
check(post("/products/new", dict(name="Salt", unit="packet", price="20"), client=s).status_code == 302, "staff can add products")
check(c.post("/products/new", data=dict(name="X", unit="kg", price="1")).status_code == 400, "POST without CSRF token rejected")

# --- bill file name: customername_RS<bill no>_HHMMSS.pdf
def disp(resp):
    return resp.headers.get("Content-Disposition", "")

post("/customers/new", dict(name="customer1", mobile="9000000001", address="x", opening_balance="0"))
with A.app.app_context():
    d = A.connect()
    c1 = d.execute("SELECT id FROM customers WHERE name='customer1'").fetchone()["id"]
    d.close()
d1 = dict(customer_id=str(c1), bill_date="2026-11-24", paid_now="0", pay_mode="Cash", note="",
          item_name=["Tomato"], qty=["2"], rate=["50"])
post("/bills/new", d1)
with A.app.app_context():
    d = A.connect()
    b3 = d.execute("SELECT * FROM bills WHERE customer_id=?", (c1,)).fetchone()
    d.close()
hhmmss = b3["created_at"][11:19].replace(":", "")
check(b3["bill_no"] == 3, "customer1 got bill number 3")
check(f"customer1_RS3_{hhmmss}.pdf" in disp(c.get(f"/bills/{b3['id']}/pdf?download=1")), "PDF named customer1_RS3_HHMMSS.pdf")
check(re.search(r"customer1_RS3_\d{6}\.pdf", disp(c.get(f"/bills/{b3['id']}/pdf"))) is not None, "same name when opened in the browser")
check(f"<title>customer1_RS3_{hhmmss}</title>" in c.get(f"/bills/{b3['id']}/thermal").data.decode(), "thermal print page title uses the same name")
check(re.search(r"Ravi_Traders_RS2_v1_\d{6}\.pdf", disp(c.get(f"/bills/{new_id}/pdf?download=1"))) is not None,
      "spaces become _, edited bill adds _v1 (Ravi_Traders_RS2_v1_HHMMSS.pdf)")

# --- permanent delete: owner only, name must be typed, safety backup, numbers never reused
check(s.get(f"/customers/{c1}/delete").status_code == 403, "staff cannot open the delete page")
check(post(f"/customers/{c1}/delete", dict(confirm_name="customer1"), client=s).status_code == 403, "staff cannot delete a customer")
check(b"Delete permanently" not in s.get(f"/customers/{c1}").data, "staff never sees the delete button")
check(b"Delete permanently" in c.get(f"/customers/{c1}").data, "owner sees the delete button")
r = post(f"/customers/{c1}/delete", dict(confirm_name="wrong"), follow_redirects=True)
check(b"does not match" in r.data, "wrong confirmation name: nothing deleted")
with A.app.app_context():
    d = A.connect()
    check(d.execute("SELECT COUNT(*) FROM customers WHERE id=?", (c1,)).fetchone()[0] == 1, "customer still exists after wrong name")
    d.close()
backups_before = len(os.listdir(os.path.join(tmp, "backups")))
r = post(f"/customers/{c1}/delete", dict(confirm_name="  CUSTOMER1 "), follow_redirects=True)
check(b"permanently deleted" in r.data, "owner can permanently delete a customer")
with A.app.app_context():
    d = A.connect()
    check(d.execute("SELECT COUNT(*) FROM customers WHERE id=?", (c1,)).fetchone()[0] == 0, "customer row removed")
    check(d.execute("SELECT COUNT(*) FROM bills WHERE customer_id=?", (c1,)).fetchone()[0] == 0, "their bills removed")
    check(d.execute("SELECT COUNT(*) FROM bill_items WHERE bill_id=?", (b3["id"],)).fetchone()[0] == 0, "their bill lines removed")
    check(d.execute("SELECT COUNT(*) FROM customer_prices WHERE customer_id=?", (c1,)).fetchone()[0] == 0, "their saved rates removed")
    check(d.execute("SELECT COUNT(*) FROM customers").fetchone()[0] == 1, "other customers untouched")
    check(d.execute("SELECT COUNT(*) FROM bills").fetchone()[0] == 3, "other customers' bills untouched")
    d.close()
check(len(os.listdir(os.path.join(tmp, "backups"))) == backups_before + 1, "safety backup saved before deleting")
d1["customer_id"] = str(cid)
post("/bills/new", d1)
with A.app.app_context():
    d = A.connect()
    check(d.execute("SELECT MAX(bill_no) FROM bills").fetchone()[0] == 4, "deleted bill number 3 is never reused (next is 4)")
    d.close()
cl = c.get("/customers?all=1")
check(cl.status_code == 200 and b"customer1" not in cl.data and b"Ravi Traders" in cl.data, "deleted customer is gone from the list (even with inactive shown)")

# --- login page and logo-as-home
lp = A.app.test_client().get("/login").data.decode()
check("logo.png" in lp and "Rajeshwari Stores" in lp, "login page shows the logo")
home = c.get("/").data.decode()
check(re.search(r'<a class="homelogo" href="/"', home) is not None, "logo in the top-left is a link to home")
print("\nALL CHECKS PASSED  (sample PDF:", os.path.join(tmp, "sample_bill.pdf") + ")")
