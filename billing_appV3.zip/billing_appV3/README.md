# Offline Billing Software

Billing for a grocery / provision store. Runs on the shop computer (Windows), works without internet, prints 80 mm thermal bills and A4 PDF bills.

## First-time setup (Windows)

1. Install **Python 3.10 or newer** from python.org. Tick **"Add Python to PATH"** during install. (Internet is needed only for this step and the first run.)
2. Copy this folder to the shop computer, e.g. `C:\Billing`.
3. Double-click **`start_billing.bat`**. The first run installs two small libraries (Flask, ReportLab); after that it works fully offline. Your browser opens at `http://127.0.0.1:5000`.
4. Keep the black window open while using the software. Close it to stop.

**First login:** username `owner`, password `owner123`. You will be asked to choose a new password straight away.

**Password rules (all fields marked * are mandatory):** at least 6 characters with a capital letter, a small letter, a number and a symbol (for example `Shop@2026`). The rules tick off live as you type. The same rules apply when the owner adds a user or resets a password.

Then go to **Settings** and enter the store name, address and mobile number (printed on every bill) and the backup folder.

## Daily use

- **Products** - add items with a unit (kg, g, piece, dozen, litre, packet) and a price per unit. **Update today's rates** changes many prices at once when market rates move.
- **Customers** - name, mobile, address and an optional opening balance (money already owed before you started using the software).
- **New Bill** - choose the customer, pick items, enter quantity. Rates start at today's default price; change any rate on the bill. Each customer's last-used rates are remembered: tick "Use this customer's last-used rates", or click the small hint under a rate.
  - Amount = quantity x rate (0.5 kg x Rs.50 = Rs.25.00). The total is rounded to the nearest rupee.
  - Enter "Paid now" (Cash or UPI). The bill prints the previous balance, this bill (item count and amount), amount paid now, and the new balance.
- **Customer ledger** - every bill and payment with a running balance. **Record payment** takes later payments.
- **Bill versions** - the owner can edit a bill, but it is saved as a new version (`12_v1`, `12_v2`...). Old versions are never overwritten. A bill can also be cancelled (kept, but no longer counted).
- **Reports (owner)** - daily sales, customer outstanding, product-wise sales.

## Printing

- **A4 PDF:** open a bill and click *Download A4 PDF* to save or share it (e.g. on WhatsApp), or *View A4 PDF* to print.
- **80 mm thermal (TVS RP 3230):**
  1. Install the TVS RP 3230 Windows driver and print a Windows test page to confirm it works.
  2. Open a bill and click *Print 80mm (thermal)*. In the print dialog choose the TVS printer, set **Margins: None**, **Scale: 100%**, turn **Headers and footers off**.
  3. If the paper size list has it, choose 80 mm roll / "3 inch". The bill layout is 72 mm wide.

## Backup to Google Drive (manual)

1. Install **Google Drive for Desktop** on the shop computer and sign in.
2. In **Settings**, set *Backup folder* to a folder inside Google Drive, e.g. `G:\My Drive\BillingBackup`.
3. Press **Backup** > **Backup now** whenever you want a copy. Drive uploads it when the computer is online.

**Restore:** close the program, copy a backup file to `data\billing.db` (replacing the current one), and start again.

## Users

Owner: everything. Staff: create bills, add customers and products, change rates, record payments, backup. Only the owner can edit or cancel bills, edit or remove payments, view reports, and change settings or users. Add staff under **Users**.

## Notes

- Data is in `data\billing.db` (one file). `data\secret.key` is created automatically; keep it with the data.
- The previous balance printed on a bill is the balance when that bill was created. If an older bill is edited later, newer printed bills keep their original figures; the customer ledger always shows the live balance.
- Run `python test_app.py` to self-test the calculations (uses a temporary database).

## Update 2 - what changed

- **Look and feel:** the Rajeshwari Stores logo is at the top-left of the login page and of every screen; clicking it always returns to the home (dashboard). Maroon, green and gold colours follow the logo, with gentle animations (page fade-in, hover lifts, counting dashboard figures). Animations switch off automatically if Windows "reduce motion" is on.
- **Bill file name:** PDFs are named `customername_RS<bill no>_<HHMMSS>.pdf`, for example `customer1_RS15_234052.pdf` for bill 15 saved at 11:40:52 pm. Spaces in the name become `_`. An edited bill adds its version, e.g. `customer1_RS15_v1_235010.pdf`. The 80 mm print page uses the same name as its title, so "Save as PDF" suggests it too.
- **Delete a customer permanently (owner only):** Customers > Delete (or the red button on the customer page). You must type the customer's name to confirm. This removes the customer with all their bills, payments and saved rates. A backup is saved automatically just before deleting, so a mistake can be restored. Bill numbers are never reused after a delete. Staff do not see this option. To only hide a customer, untick *Active* in Edit customer; tick *show inactive* on the Customers page to find them again.
